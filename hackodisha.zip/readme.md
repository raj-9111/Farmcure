Models :~

User

---

fullname - string
email - string
password - string
contact - number
picture - db
cart - array
isadmin - boolean
orders - array

Product

---

image : String,
price : Number,
name :String,
discount:Number,
bgcolor :String,
panelcolor :String,
textcolor :String

---

#### read about :-

debugus

camelcase

kabbacase

---



/				=>	login or signup

/shop			=>	shop

/user/cart			=>	cart

/admin			=>	admin panel

/owner/product	=>	show all products

/owner/admin		=>	show admin panel to create product
#   s c a t c h  
 