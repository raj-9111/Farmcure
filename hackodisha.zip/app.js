import express from "express";
import mongoose from "mongoose";
import session from "express-session";
import flash from "connect-flash";
import path from "path";
import { fileURLToPath } from "url";


import userRoutes from "./routes/userRoutes.js";
import cropRoutes from "./routes/cropRoutes.js";


const app = express();

// ================== CONFIG ==================
// ✅ Fix __dirname in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ✅ Serve static files (Tailwind compiled CSS, images, etc.)
app.use(express.static(path.join(__dirname, "public")));

// ================== SESSION & FLASH ==================
app.use(
  session({
    secret: "farmcure_secret_key",
    resave: false,
    saveUninitialized: true,
  })
);
app.use(flash());

// ✅ Pass flash + user to all views
app.use((req, res, next) => {
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  res.locals.user = req.session.user || null;
  next();
});

// ================== ROUTES ==================
app.get("/", (req, res) => res.render("index"));
app.get("/about", (req, res) => res.render("about"));
app.get("/services", (req, res) => {
  const services = [
    { icon: "leaf", color: "green", title: "Disease Detection", description: "Upload a photo and detect plant diseases instantly." },
    { icon: "medkit", color: "red", title: "Treatment Guidance", description: "Get actionable treatment suggestions tailored to your crop." },
    { icon: "cloud-upload", color: "blue", title: "Image Upload", description: "Secure and fast uploads for quick diagnosis." },
  ];
  res.render("services", { services });
});
app.get("/help", (req, res) => res.render("help"));
app.get("/profile", (req, res) => {
  if (!req.session.user) {
    req.flash("error", "You must log in first");
    return res.redirect("/users/login");
  }
  res.render("profile", { user: req.session.user });
});

// ✅ Mount routers
app.use("/users", userRoutes);
app.use("/scan", cropRoutes);

// ================== DATABASE ==================
mongoose
  .connect("mongodb://127.0.0.1:27017/farmcure", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("✅ MongoDB Connected"))
  .catch((err) => console.error("❌ MongoDB Error:", err));

// ================== SERVER ==================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
